"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";

export type ReminderState = {
  enabled: boolean;
  time: string;
  granted: boolean;
};

type ReminderPanelProps = {
  state: ReminderState;
  onChange: (state: ReminderState) => void;
};

function getReminderQuoteText(): string {
  return "حان وقت اقتباس اليوم — افتح التطبيق وابدأ يومك بالإلهام.";
}

export async function triggerReminderNotification(title: string, tag: string) {
  const body = getReminderQuoteText();
  try {
    if ("serviceWorker" in navigator) {
      const registration = await navigator.serviceWorker.getRegistration();
      if (registration) {
        await registration.showNotification(title, {
          body,
          icon: "/icons/icon-192.png",
          badge: "/icons/icon-192.png",
          tag,
          silent: false,
        });
        return;
      }
    }
  } catch {
    /* fall through to Notification */
  }
  if ("Notification" in window && Notification.permission === "granted") {
    new Notification(title, {
      body,
      icon: "/icons/icon-192.png",
      tag,
    });
  }
}

export default function ReminderPanel({ state, onChange }: ReminderPanelProps) {
  const [open, setOpen] = useState(false);

  const permissionState =
    typeof window !== "undefined" && "Notification" in window
      ? Notification.permission
      : null;

  const permissionGranted = state.granted || permissionState === "granted";

  async function handleToggle() {
    if (!state.enabled) {
      let granted = state.granted;
      if ("Notification" in window && Notification.permission !== "granted") {
        try {
          const result = await Notification.requestPermission();
          granted = result === "granted";
        } catch {
          granted = false;
        }
      }
      if (!granted) {
        setOpen(true);
        return;
      }
      onChange({ ...state, enabled: true, granted });
      if ("serviceWorker" in navigator) {
        try {
          const registration = await navigator.serviceWorker.ready;
          const anyRegistration = registration as unknown as {
            periodicSync?: { register: (tag: string, options: { minInterval: number }) => Promise<unknown> };
          };
          if (anyRegistration.periodicSync) {
            await anyRegistration.periodicSync.register("daily-reminder", {
              minInterval: 24 * 60 * 60 * 1000,
            });
          }
        } catch {
          /* Periodic Background Sync not available */
        }
      }
    } else {
      onChange({ ...state, enabled: false });
    }
  }

  function handleTest() {
    triggerReminderNotification("مولد الاقتباسات اليومية", `test-${Date.now()}`);
  }

  return (
    <div className="w-full">
      <motion.button
        type="button"
        onClick={() => setOpen((value) => !value)}
        whileHover={{ y: -1 }}
        whileTap={{ scale: 0.98 }}
        className="glass flex w-full items-center justify-between gap-3 rounded-2xl px-5 py-4 text-start transition-colors hover:bg-white/10"
      >
        <span className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-rose-500 text-white shadow-lg">
            <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
              <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
            </svg>
          </span>
          <span>
            <span className="block text-sm font-bold text-white">تذكير يومي بالاقتباس</span>
            <span className="block text-xs text-white/55">
              {state.enabled
                ? `مفعّل عند ${state.time}${permissionGranted ? "" : " (بدون إذن الإشعارات)"}`
                : "اضغط لتفعيل إشعار يومي"}
            </span>
          </span>
        </span>
        <svg
          className={`h-5 w-5 text-white/50 transition-transform duration-300 ${open ? "rotate-180" : ""}`}
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="m6 9 6 6 6-6" />
        </svg>
      </motion.button>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="overflow-hidden"
          >
            <div className="mt-3 rounded-2xl border border-white/10 bg-white/5 p-5">
              <label className="mb-2 block text-sm font-semibold text-white/85">
                وقت التذكير اليومي
              </label>
              <input
                type="time"
                value={state.time}
                onChange={(event) => onChange({ ...state, time: event.target.value })}
                className="mb-4 w-full rounded-xl border border-white/15 bg-white/10 px-4 py-2.5 text-white outline-none [color-scheme:dark] focus:border-fuchsia-400/60 focus:ring-2 focus:ring-fuchsia-400/20"
              />

              <div className="flex flex-col gap-2 sm:flex-row">
                <motion.button
                  type="button"
                  onClick={handleToggle}
                  whileTap={{ scale: 0.97 }}
                  className={`flex-1 rounded-xl px-4 py-3 text-sm font-bold text-white transition-colors ${
                    state.enabled
                      ? "border border-white/20 bg-white/10 hover:bg-white/20"
                      : "bg-gradient-to-r from-amber-400 to-rose-500 shadow-lg shadow-rose-500/25"
                  }`}
                >
                  {state.enabled ? "إيقاف التذكير" : "تفعيل التذكير"}
                </motion.button>
                <motion.button
                  type="button"
                  onClick={handleTest}
                  whileTap={{ scale: 0.97 }}
                  className="rounded-xl border border-white/15 bg-white/5 px-4 py-3 text-sm font-semibold text-white/85 transition-colors hover:bg-white/10"
                >
                  تجربة الإشعار
                </motion.button>
              </div>

              {permissionState === "denied" && (
                <p className="mt-3 text-xs text-rose-300/90">
                  تم حظر الإشعارات من إعدادات المتصفح، يمكنك تفعيلها يدويًا.
                </p>
              )}
              {state.enabled && permissionGranted && (
                <p className="mt-3 text-xs text-emerald-300/90">
                  سيصلك تذكير يوميًا عند {state.time} بوقت فتحك للتطبيق.
                </p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
