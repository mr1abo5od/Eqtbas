"use client";

import { AnimatePresence, motion } from "framer-motion";
import { islamicTypeLabel, type Quote } from "@/lib/quotes";

type QuoteCardProps = {
  quote: Quote;
  isDaily: boolean;
  copied: boolean;
  onNew: () => void;
  onCopy: () => void;
  onShare: () => void;
};

export default function QuoteCard({ quote, isDaily, copied, onNew, onCopy, onShare }: QuoteCardProps) {
  const typeBadge =
    quote.category === "islamic" && quote.type ? islamicTypeLabel[quote.type] : null;

  return (
    <div className="relative overflow-hidden rounded-[2rem] glass shadow-[0_30px_80px_-20px_rgba(0,0,0,0.7)]">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/40 to-transparent"
      />
      <div className="relative p-7 sm:p-12" style={{ transform: "translateZ(40px)" }}>
        <div className="mb-6 flex flex-wrap items-center gap-2">
          {isDaily && (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-indigo-500 to-fuchsia-500 px-3.5 py-1 text-xs font-bold text-white shadow-lg shadow-fuchsia-500/30">
              <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2l2.9 6.26L21.5 9.3l-4.8 4.6 1.2 6.9L12 17.8l-5.9 3.1 1.2-6.9L2.5 9.3l6.6-1.04L12 2z" />
              </svg>
              اقتباس اليوم
            </span>
          )}
          {typeBadge && (
            <span className="inline-flex items-center rounded-full border border-emerald-300/30 bg-emerald-400/10 px-3.5 py-1 text-xs font-semibold text-emerald-200">
              {typeBadge}
            </span>
          )}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={quote.id}
            initial={{ opacity: 0, y: 22, scale: 0.985 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -18, scale: 0.985 }}
            transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
          >
            <span aria-hidden className="mb-3 block text-7xl leading-none text-white/25">
              &ldquo;
            </span>
            <blockquote
              className={`text-[1.45rem] font-semibold leading-[2.1] text-white sm:text-[1.85rem] sm:leading-[2] ${
                quote.category === "islamic" ? "font-bold" : ""
              }`}
            >
              {quote.text}
            </blockquote>
            <div className="mt-7 flex flex-col gap-2 border-t border-white/10 pt-5 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-sm font-semibold text-white/85 sm:text-base">
                — {quote.author}
              </p>
              {quote.source && (
                <p className="text-xs font-medium text-white/50 sm:text-sm">{quote.source}</p>
              )}
            </div>
          </motion.div>
        </AnimatePresence>

        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <motion.button
            type="button"
            onClick={onNew}
            whileHover={{ y: -2, scale: 1.015 }}
            whileTap={{ scale: 0.97 }}
            className="group inline-flex flex-1 items-center justify-center gap-2 rounded-2xl bg-white px-6 py-4 text-base font-bold text-slate-900 shadow-xl shadow-white/10 transition-colors hover:bg-slate-50"
          >
            <svg
              className="h-5 w-5 transition-transform duration-500 group-hover:rotate-180"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M21 12a9 9 0 1 1-2.64-6.36" />
              <path d="M21 3v6h-6" />
            </svg>
            اقتباس جديد
          </motion.button>
          <div className="flex gap-3">
            <motion.button
              type="button"
              onClick={onCopy}
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.96 }}
              className="inline-flex flex-1 items-center justify-center gap-2 rounded-2xl border border-white/20 bg-white/10 px-5 py-4 text-base font-semibold text-white transition-colors hover:bg-white/20"
            >
              {copied ? (
                <svg className="h-5 w-5 text-emerald-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M20 6 9 17l-5-5" />
                </svg>
              ) : (
                <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
                </svg>
              )}
              <span className="hidden sm:inline">{copied ? "تم النسخ" : "نسخ"}</span>
            </motion.button>
            <motion.button
              type="button"
              onClick={onShare}
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.96 }}
              className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/20 bg-white/10 px-5 py-4 text-base font-semibold text-white transition-colors hover:bg-white/20"
            >
              <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="18" cy="5" r="3" />
                <circle cx="6" cy="12" r="3" />
                <circle cx="18" cy="19" r="3" />
                <path d="m8.6 13.5 6.8 4M15.4 6.5l-6.8 4" />
              </svg>
              <span className="hidden sm:inline">مشاركة</span>
            </motion.button>
          </div>
        </div>
      </div>
    </div>
  );
}
