export type QuoteCategory = "world" | "islamic";

export type IslamicQuoteType = "ayah" | "hadith" | "wisdom";

export type Quote = {
  id: string;
  text: string;
  author: string;
  source?: string;
  category: QuoteCategory;
  type?: IslamicQuoteType;
};

export const islamicTypeLabel: Record<IslamicQuoteType, string> = {
  ayah: "آية كريمة",
  hadith: "حديث شريف",
  wisdom: "حكمة إسلامية",
};

export const worldQuotes: Quote[] = [
  { id: "w01", text: "النجاح ليس مفتاح السعادة، بل السعادة هي مفتاح النجاح.", author: "ألبرت شفايتزر", category: "world" },
  { id: "w02", text: "ما لا تبدأه اليوم لن يكتمل غدًا، فالبداية هي نصف الطريق.", author: "مثل عربي", category: "world" },
  { id: "w03", text: "لا تدع الأمس يستهلك الكثير من اليوم.", author: "ويل روجرز", category: "world" },
  { id: "w04", text: "إن أعظم المجد ليس ألا نسقط أبدًا، بل أن ننهض في كل مرة نسقط فيها.", author: "نيلسون مانديلا", category: "world" },
  { id: "w05", text: "السعادة لا تعتمد على ما يحدث لك، بل على كيفية استجابتك لما يحدث.", author: "ديل كارنيجي", category: "world" },
  { id: "w06", text: "الطريق إلى النجاح دائمًا تحت الإنشاء.", author: "ليلي توملين", category: "world" },
  { id: "w07", text: "افعل ما تستطيع، بما لديك، أينما كنت.", author: "ثيودور روزفلت", category: "world" },
  { id: "w08", text: "لا تحسب الأيام، بل اجعل الأيام تحسب.", author: "محمد علي كلاي", category: "world" },
  { id: "w09", text: "الفشل هو ببساطة فرصة للبدء من جديد، بذكاء أكبر هذه المرة.", author: "هنري فورد", category: "world" },
  { id: "w10", text: "أفضل وقت لزراعة شجرة كان قبل عشرين عامًا، والوقت الثاني هو الآن.", author: "مثل صيني", category: "world" },
  { id: "w11", text: "الشجاعة ليست غياب الخوف، بل الحكم بأن شيئًا آخر أهم من الخوف.", author: "أمبروز ريدمون", category: "world" },
  { id: "w12", text: "القراءة هي الرحلة التي لا تحتاج إلى تذكرة.", author: "مثل فرنسي", category: "world" },
  { id: "w13", text: "لا تنتظر الظروف المثالية، اصنعها بنفسك.", author: "حكمة", category: "world" },
  { id: "w14", text: "الأمل هو أن ترى النور حتى في أحلك اللحظات.", author: "حكمة", category: "world" },
  { id: "w15", text: "الرحلة الألف ميل تبدأ بخطوة واحدة.", author: "لاو تسي", category: "world" },
  { id: "w16", text: "عندما يغلق باب، يفتح آخر، لكننا في كثير من الأحيان ننظر طويلًا إلى الباب المغلق.", author: "ألكسندر غراهام بيل", category: "world" },
  { id: "w17", text: "كل فشل يقرّبك من النجاح إذا تعلمت منه.", author: "حكمة", category: "world" },
  { id: "w18", text: "الصبر مفتاح الفرج، والعجلة مفتاح الندم.", author: "مثل عربي", category: "world" },
  { id: "w19", text: "الوقت كالسيف إن لم تقطعه قطعك.", author: "مثل عربي", category: "world" },
  { id: "w20", text: "ابتسامتك في وجه أخيك صدقة، فاجعل الابتسامة لغة يومك.", author: "حكمة", category: "world" },
  { id: "w21", text: "النجاح يجذب النجاح، فلا تبحث عن النجاح بل كن شخصًا ناجحًا.", author: "حكمة", category: "world" },
  { id: "w22", text: "إن كنت تستطيع تخيله، يمكنك تحقيقه.", author: "ألبرت أينشتاين", category: "world" },
  { id: "w23", text: "أعطني ست ساعات لقطع شجرة وسأقضي أول أربع ساعات في شحذ الفأس.", author: "أبراهام لنكولن", category: "world" },
  { id: "w24", text: "الإنسان دون هدف كالسفينة دون دفة، كلاهما ينجرف إلى لا شيء.", author: "جيمس ألن", category: "world" },
  { id: "w25", text: "من يزرع الحب يحصد السعادة، ومن يزرع الجهد يحصد التميز.", author: "حكمة", category: "world" },
  { id: "w26", text: "المرء هو مجموع أفعاله، فليكن فعلك اليوم أجمل ما فيك.", author: "حكمة", category: "world" },
  { id: "w27", text: "الجودة ليست عملاً بل عادة، وكلما ازدادت عاداتك جودة، ازدادت حياتك رقياً.", author: "حكمة", category: "world" },
  { id: "w28", text: "لا تستطيع أن تغطي الشمس بيدك، ولا أن تغطي الحقيقة بكلامك.", author: "مثل عربي", category: "world" },
  { id: "w29", text: "الغاية الوحيدة من المعرفة هي العمل بها.", author: "كونفوشيوس", category: "world" },
  { id: "w30", text: "تعلمت أن الشجاعة ليست غياب الخوف، بل الانتصار عليه.", author: "نيلسون مانديلا", category: "world" },
  { id: "w31", text: "كل ما يمكن أن يتخيله العقل ويريده الإيمان، يمكن تحقيقه.", author: "نابليون هيل", category: "world" },
  { id: "w32", text: "الحكمة أن تعرف ما يجب تجاهله.", author: "وليام جيمس", category: "world" },
  { id: "w33", text: "المستقبل ملك لمن يؤمن بجمال أحلامهم.", author: "إليانور روزفلت", category: "world" },
  { id: "w34", text: "اصنع من كل يوم ذكرى جميلة، فالحياة لحظات تتجمع.", author: "حكمة", category: "world" },
  { id: "w35", text: "الوقت الذي تستمتع به ليس وقتًا ضائعًا.", author: "مارتي روبين", category: "world" },
  { id: "w36", text: "من يزرع فكرة يحصد فعلًا، ومن يزرع فعلًا يحصد عادة، ومن يزرع عادة يحصد مصيرًا.", author: "حكمة صينية", category: "world" },
  { id: "w37", text: "لا شيء جميل يستحق السهولة في الوصول إليه.", author: "حكمة إنجليزية", category: "world" },
  { id: "w38", text: "الشمس تشرق للجميع، لكنها لا تراها إلا من يرفع رأسه.", author: "حكمة", category: "world" },
  { id: "w39", text: "الذكي من تعلم من تجارب غيره، والحكيم من تعلم من تجاربه.", author: "حكمة", category: "world" },
  { id: "w40", text: "أصدق الكلام ما صدق فعله، وخير النفع ما عاد نفعه.", author: "حكمة", category: "world" },
  { id: "w41", text: "قم بعمل صغير نحو هدفك كل يوم، فالحجر الذي يتدحرج لا يعلوه طحلب.", author: "مثل إنجليزي", category: "world" },
  { id: "w42", text: "الشجرة العظيمة تبدأ من بذرة صغيرة، والرحلة العظيمة تبدأ من حلم.", author: "حكمة", category: "world" },
];

export const islamicQuotes: Quote[] = [
  { id: "q01", text: "فَإِنَّ مَعَ الْعُسْرِ يُسْرًا", author: "القرآن الكريم", source: "سورة الشرح: 5-6", category: "islamic", type: "ayah" },
  { id: "q02", text: "وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ", author: "القرآن الكريم", source: "سورة الطلاق: 3", category: "islamic", type: "ayah" },
  { id: "q03", text: "إِنَّ اللَّهَ لَا يُغَيِّرُ مَا بِقَوْمٍ حَتَّىٰ يُغَيِّرُوا مَا بِأَنفُسِهِمْ", author: "القرآن الكريم", source: "سورة الرعد: 11", category: "islamic", type: "ayah" },
  { id: "q04", text: "فَإِذَا عَزَمْتَ فَتَوَكَّلْ عَلَى اللَّهِ", author: "القرآن الكريم", source: "سورة آل عمران: 159", category: "islamic", type: "ayah" },
  { id: "q05", text: "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ", author: "القرآن الكريم", source: "سورة البقرة: 201", category: "islamic", type: "ayah" },
  { id: "q06", text: "وَقُل رَّبِّ زِدْنِي عِلْمًا", author: "القرآن الكريم", source: "سورة طه: 114", category: "islamic", type: "ayah" },
  { id: "q07", text: "أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ", author: "القرآن الكريم", source: "سورة الرعد: 28", category: "islamic", type: "ayah" },
  { id: "q08", text: "قُلْ هُوَ اللَّهُ أَحَدٌ", author: "القرآن الكريم", source: "سورة الإخلاص: 1", category: "islamic", type: "ayah" },
  { id: "q09", text: "وَالْعَصْرِ * إِنَّ الْإِنسَانَ لَفِي خُسْرٍ", author: "القرآن الكريم", source: "سورة العصر: 1-2", category: "islamic", type: "ayah" },
  { id: "q10", text: "وَأَن لَّيْسَ لِلْإِنسَانِ إِلَّا مَا سَعَىٰ", author: "القرآن الكريم", source: "سورة النجم: 39", category: "islamic", type: "ayah" },
  { id: "q11", text: "وَعَسَىٰ أَن تَكْرَهُوا شَيْئًا وَهُوَ خَيْرٌ لَّكُمْ وَعَسَىٰ أَن تُحِبُّوا شَيْئًا وَهُوَ شَرٌّ لَّكُمْ", author: "القرآن الكريم", source: "سورة البقرة: 216", category: "islamic", type: "ayah" },
  { id: "q12", text: "لَا تَحْزَنْ إِنَّ اللَّهَ مَعَنَا", author: "القرآن الكريم", source: "سورة التوبة: 40", category: "islamic", type: "ayah" },
  { id: "q13", text: "وَقُلِ اعْمَلُوا فَسَيَرَى اللَّهُ عَمَلَكُمْ", author: "القرآن الكريم", source: "سورة التوبة: 105", category: "islamic", type: "ayah" },
  { id: "q14", text: "ادْعُونِي أَسْتَجِبْ لَكُمْ", author: "القرآن الكريم", source: "سورة غافر: 60", category: "islamic", type: "ayah" },
  { id: "q15", text: "إِنَّمَا الْأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى", author: "الحديث الشريف", source: "متفق عليه", category: "islamic", type: "hadith" },
  { id: "q16", text: "الْمُسْلِمُ مَنْ سَلِمَ الْمُسْلِمُونَ مِنْ لِسَانِهِ وَيَدِهِ", author: "الحديث الشريف", source: "متفق عليه", category: "islamic", type: "hadith" },
  { id: "q17", text: "خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ", author: "الحديث الشريف", source: "رواه البخاري", category: "islamic", type: "hadith" },
  { id: "q18", text: "الطُّهُورُ شَطْرُ الْإِيمَانِ", author: "الحديث الشريف", source: "رواه مسلم", category: "islamic", type: "hadith" },
  { id: "q19", text: "مَنْ سَلَكَ طَرِيقًا يَلْتَمِسُ فِيهِ عِلْمًا سَهَّلَ اللَّهُ لَهُ بِهِ طَرِيقًا إِلَى الْجَنَّةِ", author: "الحديث الشريف", source: "رواه مسلم", category: "islamic", type: "hadith" },
  { id: "q20", text: "لَا يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لِأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ", author: "الحديث الشريف", source: "متفق عليه", category: "islamic", type: "hadith" },
  { id: "q21", text: "الْكَلِمَةُ الطَّيِّبَةُ صَدَقَةٌ", author: "الحديث الشريف", source: "متفق عليه", category: "islamic", type: "hadith" },
  { id: "q22", text: "إِنَّ اللَّهَ جَمِيلٌ يُحِبُّ الْجَمَالَ", author: "الحديث الشريف", source: "رواه مسلم", category: "islamic", type: "hadith" },
  { id: "q23", text: "اتَّقِ اللَّهَ حَيْثُمَا كُنْتَ، وَأَتْبِعِ السَّيِّئَةَ الْحَسَنَةَ تَمْحُهَا، وَخَالِقِ النَّاسَ بِخُلُقٍ حَسَنٍ", author: "الحديث الشريف", source: "رواه الترمذي", category: "islamic", type: "hadith" },
  { id: "q24", text: "الدِّينُ النَّصِيحَةُ", author: "الحديث الشريف", source: "رواه مسلم", category: "islamic", type: "hadith" },
  { id: "q25", text: "مَا نَقَصَتْ صَدَقَةٌ مِنْ مَالٍ", author: "الحديث الشريف", source: "رواه مسلم", category: "islamic", type: "hadith" },
  { id: "q26", text: "احْرِصْ عَلَى مَا يَنْفَعُكَ، وَاسْتَعِنْ بِاللَّهِ وَلَا تَعْجَزْ", author: "الحديث الشريف", source: "رواه مسلم", category: "islamic", type: "hadith" },
  { id: "q27", text: "مَنْ كَانَ يُؤْمِنُ بِاللَّهِ وَالْيَوْمِ الْآخِرِ فَلْيَقُلْ خَيْرًا أَوْ لِيَصْمُتْ", author: "الحديث الشريف", source: "متفق عليه", category: "islamic", type: "hadith" },
  { id: "q28", text: "يَسِّرُوا وَلَا تُعَسِّرُوا، وَبَشِّرُوا وَلَا تُنَفِّرُوا", author: "الحديث الشريف", source: "متفق عليه", category: "islamic", type: "hadith" },
  { id: "q29", text: "مَثَلُ الْمُؤْمِنِينَ فِي تَوَادِّهِمْ وَتَرَاحُمِهِمْ كَمَثَلِ الْجَسَدِ الْوَاحِدِ", author: "الحديث الشريف", source: "متفق عليه", category: "islamic", type: "hadith" },
  { id: "q30", text: "الرَّاحِمُونَ يَرْحَمُهُمُ الرَّحْمَنُ، ارْحَمُوا مَنْ فِي الْأَرْضِ يَرْحَمْكُمْ مَنْ فِي السَّمَاءِ", author: "الحديث الشريف", source: "رواه الترمذي", category: "islamic", type: "hadith" },
  { id: "q31", text: "لَا ضَرَرَ وَلَا ضِرَارَ", author: "الحديث الشريف", source: "رواه ابن ماجه وأحمد", category: "islamic", type: "hadith" },
  { id: "q32", text: "اغْتَنِمْ خَمْسًا قَبْلَ خَمْسٍ: شَبَابَكَ قَبْلَ هَرَمِكَ، وَصِحَّتَكَ قَبْلَ سَقَمِكَ", author: "الحديث الشريف", source: "رواه الحاكم", category: "islamic", type: "hadith" },
  { id: "q33", text: "الصَّبْرُ جِزَاؤُهُ الْجَنَّةُ، وَمَعَ الصَّبْرِ يَأْتِي الْفَرَجُ", author: "حكمة إسلامية", category: "islamic", type: "wisdom" },
  { id: "q34", text: "الذِّكْرُ يُطَمْئِنُ الْقَلْبَ وَيُزِيلُ الْهَمَّ", author: "حكمة إسلامية", category: "islamic", type: "wisdom" },
  { id: "q35", text: "التَّوَكُّلُ عَلَى اللَّهِ لَا يَعْنِي تَرْكَ الْأَخْذِ بِالْأَسْبَابِ", author: "حكمة إسلامية", category: "islamic", type: "wisdom" },
  { id: "q36", text: "اجْعَلِ الْقُرْآنَ رَفِيقَكَ فِي كُلِّ صَبَاحٍ، تَجِدْ نُورًا فِي دَرْبِكَ", author: "حكمة إسلامية", category: "islamic", type: "wisdom" },
  { id: "q37", text: "الْعِلْمُ نُورٌ، وَالْعَامِلُ بِهِ مُهْتَدٍ بِإِذْنِ اللَّهِ", author: "حكمة إسلامية", category: "islamic", type: "wisdom" },
  { id: "q38", text: "الدُّعَاءُ سِلَاحُ الْمُؤْمِنِ، فَلَا تَسْتَحْقِرَنَّ مِنَ الدُّعَاءِ شَيْئًا", author: "حكمة إسلامية", category: "islamic", type: "wisdom" },
];

export function getQuotesByCategory(category: QuoteCategory): Quote[] {
  return category === "world" ? worldQuotes : islamicQuotes;
}

export const allQuotes: Quote[] = [...worldQuotes, ...islamicQuotes];

export function findQuoteById(id: string | null): Quote | null {
  if (!id) return null;
  return allQuotes.find((quote) => quote.id === id) ?? null;
}
